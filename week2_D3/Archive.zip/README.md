# DiceGameGamble

## Game Play
	- Start new game
	- Roll Dice until dice is 
	- If 

## How To?
	1. Start
